﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DomainEventExample2
{
    /// <summary>
    /// 领域对象事件标示：（标示接口，接口的一种，用来约束一批对象）IEvent,事件源 （https://www.jianshu.com/p/c10b7fd9bec1）
    /// 事件实体基类 IEvent接口，标示接口
    /// </summary>
    public interface IEvent
    {

    }
}
