using System;
using System.Threading.Tasks;

namespace iConsole
{
    public delegate Task RequestDelegate(HttpContext context);

}