using System;

namespace iConsole
{
    public class HttpContext
    {
        
    }
}